from django.db import models

class Book(models.Model):
    bid = models.IntegerField(primary_key=True)  #책id
    title = models.CharField(max_length=50)  #책제목
    author = models.CharField(max_length=50)  #저자
    category = models.CharField(max_length=50)  #카테고리
    pages = models.IntegerField()  #페이지수
    price = models.IntegerField()  #가격
    published_date = models.DateField() #출판일
    description = models.TextField()

# Create your models here.
