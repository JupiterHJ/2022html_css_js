from django.urls import path, include
from django.contrib import admin

urlpatterns = [
    path("admin/", admin.site.urls),
    path("example/", include("example.urls"))
]

from django.urls import path, include
from example.views import HelloAPI

urlpatterns = [
    path("hello/", HelloAPI),
]
