# users/models.py

from django.db import models
from django.contrib.auth.models import User 
from django.db.models.signals import post_save
from django.dispatch import receiver

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    #on_delete를 통해, 데이터가 삭제될 때 전에 연결된 데이터도 함께 삭제되게 함.
    nickname = models.CharField(max_length=128)
    position = models.CharField(max_length=128)
    subjects = models.CharField(max_length=128) 
    image = models.ImageField(upload_to='profile/', default='default.png')
    #ImageField 통해 미디어 파일을 주고 받는 과정에서 기본값 처리

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)
#@receiver로 프로필 생성해주는 코드를 직접 작성하지 않아도 알아서 유저 생성 이벤트를 감지해 자동 생성