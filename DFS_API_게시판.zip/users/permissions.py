# users/permissions.py
from rest_framework import permissions

class CustomReadOnly(permissions.BasePermission): 
#permissions.Base~ 상속 받아와 작성.
# GET: 누구나, PUT/PATCH: 해당 유저

    def has_object_permission(self, request, view, obj): 
        if request.method in permissions.SAFE_METHODS:
        #safe_methods는 데이터에 영향 미치지 않는 메소드, GET과 같은 메소드 의미.
            return True
        return obj.user == request.user
        #PUT,PATCH는 요청으로 들어온 유저와 객체 유저를 비교해 같으면 통과. 같지 않으면 프로필을 수정할 수 없음.